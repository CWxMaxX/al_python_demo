name = """Saman " Perera 
            Like to go to Kandy"""
name2 = 'Saman"              Perera'
nameNew = name + name2


print(nameNew)

############################################
testStr = "2021\\08\\23"
testStr2 = "2021\'08\'23"
testStr3 = "2021\n08\n23"  # new Line ec - \n
testStr4 = "Saman\f Perera"
testStr5 = "Saman\tPerera"
testStr6 = "Saman Per\bera"
testStr7 = "0773173356\r*******"


print(testStr)
print(testStr2)
print(testStr3)
print(testStr4)
print(testStr5)
print(testStr6)
print(testStr7)
rawString = r"http:\\www.python.org"
print(rawString)

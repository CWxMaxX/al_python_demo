x = int(input("Enter value = "))
counter = 1

while counter <= x:
    print("*"*counter)
    counter += 1
